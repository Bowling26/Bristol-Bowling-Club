BRISTOL BOWLING CLUB WEBSITE STARTER

Files:
- index.html: website content and sections
- style.css: responsive design and colours
- script.js: mobile navigation and current year
- assets/club-logo.jpg: supplied club crest, cropped to remove black bars

PREVIEW:
Open index.html in a web browser.

PUBLISH FREE:
A static website like this can be hosted free on services such as GitHub Pages or Netlify. Upload the contents of this folder to the hosting service. Before publishing, replace placeholder fixture/news/gallery information with confirmed club information and check that the crest image is approved for club website use.

Current details included:
Address: Duckmoor Road, BS3 2EN
Email: bristolbowling@yahoo.com
Facebook: https://www.facebook.com/share/1HS8hErG2k/?mibextid=wwXIfr
Telephone: not supplied

This is a starter website; no live hosting or domain has been set up yet.
